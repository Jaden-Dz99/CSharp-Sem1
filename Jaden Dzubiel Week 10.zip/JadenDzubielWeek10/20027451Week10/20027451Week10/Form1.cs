﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20027451Week10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calc_Click(object sender, EventArgs e)
        {
            DateTime dte_today = DateTime.Today;
            TimeSpan tsp_interval;
            int int_repayment;
            int int_interval_stop;

            list_display.Items.Clear();

            int_repayment = Convert.ToInt32(txt_repayments.Text);
            tsp_interval = TimeSpan.Parse(txt_intervals.Text);
            int_interval_stop = 1;

            while (int_interval_stop <= int_repayment)
            {
                dte_today.Add(tsp_interval);
                list_display.Items.Add(int_interval_stop + "\t\t" + dte_today);
                dte_today += tsp_interval;
                int_interval_stop++;
            }
        }
    }
}
