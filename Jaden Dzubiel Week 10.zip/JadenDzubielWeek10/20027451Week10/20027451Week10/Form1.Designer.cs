﻿namespace _20027451Week10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_repayments = new System.Windows.Forms.TextBox();
            this.txt_intervals = new System.Windows.Forms.TextBox();
            this.btn_calc = new System.Windows.Forms.Button();
            this.list_display = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Repayments: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Repayment Intervals:";
            // 
            // txt_repayments
            // 
            this.txt_repayments.Location = new System.Drawing.Point(230, 27);
            this.txt_repayments.Name = "txt_repayments";
            this.txt_repayments.Size = new System.Drawing.Size(100, 20);
            this.txt_repayments.TabIndex = 2;
            // 
            // txt_intervals
            // 
            this.txt_intervals.Location = new System.Drawing.Point(230, 53);
            this.txt_intervals.Name = "txt_intervals";
            this.txt_intervals.Size = new System.Drawing.Size(100, 20);
            this.txt_intervals.TabIndex = 3;
            // 
            // btn_calc
            // 
            this.btn_calc.Location = new System.Drawing.Point(230, 97);
            this.btn_calc.Name = "btn_calc";
            this.btn_calc.Size = new System.Drawing.Size(100, 23);
            this.btn_calc.TabIndex = 4;
            this.btn_calc.Text = "Calculate";
            this.btn_calc.UseVisualStyleBackColor = true;
            this.btn_calc.Click += new System.EventHandler(this.btn_calc_Click);
            // 
            // list_display
            // 
            this.list_display.FormattingEnabled = true;
            this.list_display.Location = new System.Drawing.Point(49, 147);
            this.list_display.Name = "list_display";
            this.list_display.Size = new System.Drawing.Size(281, 199);
            this.list_display.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 384);
            this.Controls.Add(this.list_display);
            this.Controls.Add(this.btn_calc);
            this.Controls.Add(this.txt_intervals);
            this.Controls.Add(this.txt_repayments);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_repayments;
        private System.Windows.Forms.TextBox txt_intervals;
        private System.Windows.Forms.Button btn_calc;
        private System.Windows.Forms.ListBox list_display;
    }
}

