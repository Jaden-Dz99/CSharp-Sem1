﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

// Programmer: Jaden Dzubiel
// ID: 20027451
// Program to accept sales and provide details of available products in stock and to store details about the sales

namespace JadenDzubiel20027451
{
    public partial class Form1 : Form
    {

        // Declare variables
        int[] int_quantity = new int[150];
        double[] dec_charge = new double[150];

        public Form1()
        {
            InitializeComponent();
        }

        int selectedItem, inStock, saleQuantity;
        double saleAmount, retailPrice;

        // Structure for Products
        public struct Products
        {
            public string strCode;
            public string strName;
            public int intStock;
            public double dblPrice;
            public string strImage;

        }

        // Structure for Sales
        public struct Sales
        {
            public string strCode;
            public string strName;
            public int intStock;
            public double dblPrice;
            public string strImage;
        }

        // List that hold all products and sales data
        List<Products> lstProducts = new List<Products>();
        List<Sales> lstSales = new List<Sales>();

        private void Form1_Load(object sender, EventArgs e)
        {
            // Code that reads .txt file
            StreamReader inFile;
            inFile = File.OpenText("products.txt");
            string strRead;
            while ((strRead = inFile.ReadLine()) != null)
            {
                Products PrdObj;
                string[] strTempArr = new string[5];
                strTempArr = strRead.Split(',');
                PrdObj.strCode = strTempArr[0];
                PrdObj.strName = strTempArr[1];
                PrdObj.intStock = int.Parse(strTempArr[2]);
                PrdObj.dblPrice = double.Parse(strTempArr[3]);
                PrdObj.strImage = strTempArr[4];
                lstProducts.Add(PrdObj);
            }
            foreach (Products PrdObj in lstProducts)
            {
                listBox1.Items.Add(PrdObj.strName);

                txt_quantity.SelectAll();
                txt_quantity.Focus();
                btn_confirm.Visible = false;
                btn_cancel.Visible = false;

                txt_quantity.Text = "0";

                this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

            }
            inFile.Close();
        }
        // Selected items display picture and price
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedItem = listBox1.SelectedIndex;

            if (listBox1.SelectedIndex == -1)
            {
                txt_retail.Clear();
            }
            else
            {
                txt_retail.Text = (lstProducts[selectedItem].dblPrice * 1.5).ToString("c");
            }

            if (listBox1.SelectedIndex == -1)
            {
                pictureBox1.Image = null;
            }
            else
            {
                pictureBox1.Image = Image.FromFile(lstProducts[selectedItem].strImage);
                txt_quantity.Focus();
            }
        }

        private void btn_sell_Click(object sender, EventArgs e)
        {
            retailPrice = lstProducts[selectedItem].dblPrice * 1.5;
            inStock = lstProducts[selectedItem].intStock;


            if (!int.TryParse(txt_quantity.Text, out saleQuantity))
            {
                MessageBox.Show("Please re-enter a number");  // If no value, error message.
                txt_quantity.Clear(); // Clear textbox  
                txt_quantity.Focus(); // Focus textbox
            }
            if (saleQuantity < 0)
            {
                MessageBox.Show("Cannot enter negative value"); // If Value is negative, error message.
                txt_quantity.Clear(); // Clear textbox  
                txt_quantity.Focus(); // Focus Textbox 
                txt_cost.Text = "0";
            }
            if (inStock < saleQuantity)
            {
                MessageBox.Show("Not enough stock of that item"); // If item not in stock, error message.
                txt_quantity.Clear(); // Clear textbox  
                txt_quantity.Focus(); // Focus Textbox 
            }
            else
            {
                saleAmount = saleQuantity * retailPrice; // Equation 
                txt_cost.Text = saleAmount.ToString("C");

                btn_confirm.Visible = true; // Show confirm button
                btn_cancel.Visible = true; // Show cancel button
            }
        }
        // Confirm sale populates data for sale summary form
        private void btn_confirm_Click(object sender, EventArgs e)
        {
            Sales sale1 = new Sales();
            sale1.strName = lstProducts[selectedItem].strName;
            sale1.dblPrice = retailPrice;
            sale1.intStock = saleQuantity;
            sale1.dblPrice = saleAmount;
            lstSales.Add(sale1);

            Products products2 = new Products();
            products2.strCode = lstProducts[selectedItem].strCode;
            products2.strName = lstProducts[selectedItem].strName;
            products2.intStock = lstProducts[selectedItem].intStock;
            products2.dblPrice = lstProducts[selectedItem].dblPrice;
            products2.strImage = lstProducts[selectedItem].strImage;
            lstProducts.Add(products2);

            lstProducts.Remove(lstProducts[selectedItem]);
            listBox1.Items.RemoveAt(selectedItem);
            listBox1.Items.Add(products2.strName);

            txt_quantity.Clear();
            txt_retail.Clear();
            txt_cost.Clear();
            pictureBox1.Image = null;
            btn_confirm.Visible = false;
            btn_cancel.Visible = false;
        }

        private void btn_sale_Click(object sender, EventArgs e)
        {
            // Create and pass data to second form
            double total = 0;
            Form2 frm_summary = new Form2();
            frm_summary.txt_totalSales.Text = lstSales.Count.ToString();

            frm_summary.lst_products.Items.Add("Items \t\t Quantity \t\t Price");
            foreach (Sales newSale in lstSales)
            {
                // Add each enw sale to the sales summary listbox
                frm_summary.lst_products.Items.Add(newSale.strName + "\t\t" + newSale.intStock.ToString("C") + "\t\t" + newSale.dblPrice.ToString("C"));
            }

            foreach (Sales newSale in lstSales)
            {
                // Add each new sale in total 
                total += newSale.dblPrice;
            }
            frm_summary.txt_totalValue.Text = total.ToString("C");
            frm_summary.ShowDialog();
        }
        // Restore defaults
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            txt_retail.Clear();
            txt_quantity.Clear();
            txt_cost.Clear();
            pictureBox1.Image = null;

            btn_confirm.Visible = false;
            btn_cancel.Visible = false;
        }
        // If Escape key pressed, close form.
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
             if (keyData == Keys.Escape)
             {
                this.Close();
                return true;
             }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
