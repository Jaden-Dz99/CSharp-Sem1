﻿namespace JadenDzubiel20027451
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_totalSales = new System.Windows.Forms.TextBox();
            this.txt_totalValue = new System.Windows.Forms.TextBox();
            this.lst_products = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total No of Sales";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Total Value";
            // 
            // txt_totalSales
            // 
            this.txt_totalSales.Location = new System.Drawing.Point(179, 24);
            this.txt_totalSales.Name = "txt_totalSales";
            this.txt_totalSales.ReadOnly = true;
            this.txt_totalSales.Size = new System.Drawing.Size(100, 20);
            this.txt_totalSales.TabIndex = 2;
            this.txt_totalSales.TextChanged += new System.EventHandler(this.txt_totalSales_TextChanged);
            // 
            // txt_totalValue
            // 
            this.txt_totalValue.Location = new System.Drawing.Point(179, 73);
            this.txt_totalValue.Name = "txt_totalValue";
            this.txt_totalValue.ReadOnly = true;
            this.txt_totalValue.Size = new System.Drawing.Size(100, 20);
            this.txt_totalValue.TabIndex = 3;
            // 
            // lst_products
            // 
            this.lst_products.FormattingEnabled = true;
            this.lst_products.Location = new System.Drawing.Point(27, 112);
            this.lst_products.Name = "lst_products";
            this.lst_products.Size = new System.Drawing.Size(252, 134);
            this.lst_products.TabIndex = 4;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 271);
            this.Controls.Add(this.lst_products);
            this.Controls.Add(this.txt_totalValue);
            this.Controls.Add(this.txt_totalSales);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.ListBox lst_products;
        public System.Windows.Forms.TextBox txt_totalSales;
        public System.Windows.Forms.TextBox txt_totalValue;
    }
}