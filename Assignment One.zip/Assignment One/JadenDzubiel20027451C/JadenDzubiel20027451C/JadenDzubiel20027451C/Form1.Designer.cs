﻿namespace JadenDzubiel20027451C
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_value = new System.Windows.Forms.TextBox();
            this.lbl_value = new System.Windows.Forms.Label();
            this.btn_inches = new System.Windows.Forms.Button();
            this.btn_feet = new System.Windows.Forms.Button();
            this.btn_yards = new System.Windows.Forms.Button();
            this.btn_miles = new System.Windows.Forms.Button();
            this.grp_box = new System.Windows.Forms.GroupBox();
            this.btn_exit = new System.Windows.Forms.Button();
            this.lbl_imperial = new System.Windows.Forms.Label();
            this.txt_answer = new System.Windows.Forms.TextBox();
            this.lbl_metric = new System.Windows.Forms.Label();
            this.lbl_equals = new System.Windows.Forms.Label();
            this.grp_box.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_value
            // 
            this.txt_value.BackColor = System.Drawing.Color.White;
            this.txt_value.Location = new System.Drawing.Point(24, 25);
            this.txt_value.Name = "txt_value";
            this.txt_value.Size = new System.Drawing.Size(63, 20);
            this.txt_value.TabIndex = 4;
            this.txt_value.Click += new System.EventHandler(this.revert);
            this.txt_value.TextChanged += new System.EventHandler(this.txt_value_TextChanged);
            // 
            // lbl_value
            // 
            this.lbl_value.AutoSize = true;
            this.lbl_value.Location = new System.Drawing.Point(21, 12);
            this.lbl_value.Name = "lbl_value";
            this.lbl_value.Size = new System.Drawing.Size(157, 13);
            this.lbl_value.TabIndex = 5;
            this.lbl_value.Text = "Enter the value to be converted";
            // 
            // btn_inches
            // 
            this.btn_inches.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btn_inches.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_inches.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_inches.Location = new System.Drawing.Point(12, 19);
            this.btn_inches.Name = "btn_inches";
            this.btn_inches.Size = new System.Drawing.Size(154, 27);
            this.btn_inches.TabIndex = 0;
            this.btn_inches.Text = "&Inches to Centimetres";
            this.btn_inches.UseVisualStyleBackColor = false;
            this.btn_inches.Click += new System.EventHandler(this.btn_inches_Click);
            // 
            // btn_feet
            // 
            this.btn_feet.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btn_feet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_feet.Location = new System.Drawing.Point(12, 52);
            this.btn_feet.Name = "btn_feet";
            this.btn_feet.Size = new System.Drawing.Size(154, 27);
            this.btn_feet.TabIndex = 1;
            this.btn_feet.Text = "&Feet to Metres";
            this.btn_feet.UseVisualStyleBackColor = false;
            this.btn_feet.Click += new System.EventHandler(this.btn_feet_Click);
            // 
            // btn_yards
            // 
            this.btn_yards.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btn_yards.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_yards.Location = new System.Drawing.Point(12, 85);
            this.btn_yards.Name = "btn_yards";
            this.btn_yards.Size = new System.Drawing.Size(154, 27);
            this.btn_yards.TabIndex = 2;
            this.btn_yards.Text = "&Yards to Metres";
            this.btn_yards.UseVisualStyleBackColor = false;
            this.btn_yards.Click += new System.EventHandler(this.btn_yards_Click);
            // 
            // btn_miles
            // 
            this.btn_miles.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btn_miles.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_miles.Location = new System.Drawing.Point(12, 118);
            this.btn_miles.Name = "btn_miles";
            this.btn_miles.Size = new System.Drawing.Size(154, 27);
            this.btn_miles.TabIndex = 3;
            this.btn_miles.Text = "&Miles to Kilometres";
            this.btn_miles.UseVisualStyleBackColor = false;
            this.btn_miles.Click += new System.EventHandler(this.btn_miles_Click);
            // 
            // grp_box
            // 
            this.grp_box.Controls.Add(this.btn_miles);
            this.grp_box.Controls.Add(this.btn_yards);
            this.grp_box.Controls.Add(this.btn_feet);
            this.grp_box.Controls.Add(this.btn_inches);
            this.grp_box.ForeColor = System.Drawing.SystemColors.Highlight;
            this.grp_box.Location = new System.Drawing.Point(12, 94);
            this.grp_box.Name = "grp_box";
            this.grp_box.Size = new System.Drawing.Size(186, 155);
            this.grp_box.TabIndex = 6;
            this.grp_box.TabStop = false;
            this.grp_box.Text = "Type of conversion";
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btn_exit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_exit.Location = new System.Drawing.Point(204, 213);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(72, 24);
            this.btn_exit.TabIndex = 7;
            this.btn_exit.Text = "E&xit";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // lbl_imperial
            // 
            this.lbl_imperial.AutoSize = true;
            this.lbl_imperial.Location = new System.Drawing.Point(93, 28);
            this.lbl_imperial.Name = "lbl_imperial";
            this.lbl_imperial.Size = new System.Drawing.Size(28, 13);
            this.lbl_imperial.TabIndex = 8;
            this.lbl_imperial.Text = "XXX";
            // 
            // txt_answer
            // 
            this.txt_answer.BackColor = System.Drawing.Color.White;
            this.txt_answer.Location = new System.Drawing.Point(204, 25);
            this.txt_answer.Name = "txt_answer";
            this.txt_answer.ReadOnly = true;
            this.txt_answer.Size = new System.Drawing.Size(63, 20);
            this.txt_answer.TabIndex = 9;
            // 
            // lbl_metric
            // 
            this.lbl_metric.AutoSize = true;
            this.lbl_metric.Location = new System.Drawing.Point(273, 28);
            this.lbl_metric.Name = "lbl_metric";
            this.lbl_metric.Size = new System.Drawing.Size(28, 13);
            this.lbl_metric.TabIndex = 10;
            this.lbl_metric.Text = "XXX";
            // 
            // lbl_equals
            // 
            this.lbl_equals.AutoSize = true;
            this.lbl_equals.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_equals.Location = new System.Drawing.Point(156, 25);
            this.lbl_equals.Name = "lbl_equals";
            this.lbl_equals.Size = new System.Drawing.Size(22, 24);
            this.lbl_equals.TabIndex = 11;
            this.lbl_equals.Text = "=";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(407, 261);
            this.Controls.Add(this.lbl_equals);
            this.Controls.Add(this.lbl_metric);
            this.Controls.Add(this.txt_answer);
            this.Controls.Add(this.lbl_imperial);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.grp_box);
            this.Controls.Add(this.lbl_value);
            this.Controls.Add(this.txt_value);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Distance Converter";
            this.grp_box.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_value;
        private System.Windows.Forms.Label lbl_value;
        private System.Windows.Forms.Button btn_inches;
        private System.Windows.Forms.Button btn_feet;
        private System.Windows.Forms.Button btn_yards;
        private System.Windows.Forms.Button btn_miles;
        private System.Windows.Forms.GroupBox grp_box;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Label lbl_imperial;
        private System.Windows.Forms.TextBox txt_answer;
        private System.Windows.Forms.Label lbl_metric;
        private System.Windows.Forms.Label lbl_equals;
    }
}

