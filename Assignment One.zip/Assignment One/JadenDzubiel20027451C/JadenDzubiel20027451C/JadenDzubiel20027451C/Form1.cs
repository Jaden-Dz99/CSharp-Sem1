﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubiel20027451C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // When the form is running, the answer, imperial label, metric label, and the equals sign is 
            //not visible.

            txt_answer.Visible = false;
            lbl_imperial.Visible = false;
            lbl_metric.Visible = false;
            lbl_equals.Visible = false;

        }

        private void btn_inches_Click(object sender, EventArgs e)
        {
            double dblValue, dblConversion;

            if (!double.TryParse(txt_value.Text, out dblValue))
            {
                MessageBox.Show("A number was not entered – please enter value again");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            if (dblValue < 0)
            {
                MessageBox.Show("A negative value was entered – please enter a positive value instead");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            dblValue = double.Parse(txt_value.Text);
            dblConversion = (dblValue * 0.3048);
            txt_answer.Text = dblConversion.ToString();
            lbl_metric.Text = "centimetre";
            lbl_imperial.Text = "inches";

            txt_answer.Visible = true;
            lbl_imperial.Visible = true;
            lbl_metric.Visible = true;
            lbl_equals.Visible = true;
        }

        // All comments shown previous are presumed for following actions.

        private void btn_feet_Click(object sender, EventArgs e)
        {
            // CONVERSION || 1 foot = 0.3048 metres
            double dblValue, dblConversion;

            if (!double.TryParse(txt_value.Text, out dblValue))
            {
                MessageBox.Show("A number was not entered – please enter value again");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            if (dblValue < 0)
            {
                MessageBox.Show("A negative value was entered – please enter a positive value instead");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            dblValue = double.Parse(txt_value.Text);
            dblConversion = (dblValue * 0.3048);
            txt_answer.Text = dblConversion.ToString();
            lbl_metric.Text = "metres";
            lbl_imperial.Text = "feet";

            txt_answer.Visible = true;
            lbl_imperial.Visible = true;
            lbl_metric.Visible = true;
            lbl_equals.Visible = true;
        }

        private void btn_yards_Click(object sender, EventArgs e)
        {
            // CONVERSION || 1 yard = 0.9144 metres 
            double dblValue, dblConversion;

            if (!double.TryParse(txt_value.Text, out dblValue))
            {
                MessageBox.Show("A number was not entered – please enter value again");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            if (dblValue < 0)
            {
                MessageBox.Show("A negative value was entered – please enter a positive value instead");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            dblValue = double.Parse(txt_value.Text);
            dblConversion = (dblValue * 0.9144);
            txt_answer.Text = dblConversion.ToString();
            lbl_metric.Text = "metres";
            lbl_imperial.Text = "yards";

            txt_answer.Visible = true;
            lbl_imperial.Visible = true;
            lbl_metric.Visible = true;
            lbl_equals.Visible = true;
        }

        private void btn_miles_Click(object sender, EventArgs e)
        {
            // CONVERSION || 1 mile = 1.609 kilometres 
            double dblValue, dblConversion;

            if (!double.TryParse(txt_value.Text, out dblValue))
            {
                MessageBox.Show("A number was not entered – please enter value again");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            if (dblValue < 0)
            {
                MessageBox.Show("A negative value was entered – please enter a positive value instead");
                txt_value.Clear();
                txt_value.Focus();
                return;
            }

            dblValue = double.Parse(txt_value.Text);
            dblConversion = (dblValue * 1.609);
            txt_answer.Text = dblConversion.ToString();
            lbl_metric.Text = "kilometres";
            lbl_imperial.Text = "miles";

            txt_answer.Visible = true;
            lbl_imperial.Visible = true;
            lbl_metric.Visible = true;
            lbl_equals.Visible = true;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Code from - stackoverflow
        // https://stackoverflow.com/questions/2290959/escape-button-to-close-windows-forms-form-in-c-sharp
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            if (keyData == Keys.Tab)
            {
                // Reverts to normal display when Tab key is entered
                txt_answer.Visible = false;
                lbl_imperial.Visible = false;
                lbl_metric.Visible = false;
                lbl_equals.Visible = false;
                // Clears previous number
                txt_value.Clear();
                txt_value.Focus();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void revert(object sender, EventArgs e)
        {
            // Reverts to normal display when first text box is clicked
            txt_answer.Visible = false;
            lbl_imperial.Visible = false;
            lbl_metric.Visible = false;
            lbl_equals.Visible = false;
            // Clears previous number
            txt_value.Clear();
            txt_value.Focus();
        }

        private void txt_value_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
