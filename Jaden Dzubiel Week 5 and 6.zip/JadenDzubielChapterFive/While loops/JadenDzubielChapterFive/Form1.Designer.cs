﻿namespace JadenDzubielChapterFive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_displayMultiplication = new System.Windows.Forms.Button();
            this.list_display = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_displayMultiplication
            // 
            this.btn_displayMultiplication.Location = new System.Drawing.Point(33, 31);
            this.btn_displayMultiplication.Name = "btn_displayMultiplication";
            this.btn_displayMultiplication.Size = new System.Drawing.Size(183, 35);
            this.btn_displayMultiplication.TabIndex = 0;
            this.btn_displayMultiplication.Text = "Display Three Times Tables";
            this.btn_displayMultiplication.UseVisualStyleBackColor = true;
            this.btn_displayMultiplication.Click += new System.EventHandler(this.btn_displayMultiplication_Click);
            // 
            // list_display
            // 
            this.list_display.FormattingEnabled = true;
            this.list_display.Location = new System.Drawing.Point(35, 80);
            this.list_display.Name = "list_display";
            this.list_display.Size = new System.Drawing.Size(180, 329);
            this.list_display.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(255, 450);
            this.Controls.Add(this.list_display);
            this.Controls.Add(this.btn_displayMultiplication);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_displayMultiplication;
        private System.Windows.Forms.ListBox list_display;
    }
}

