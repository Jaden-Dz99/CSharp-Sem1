﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Programmer: JADEN DZUBIEL
//Number: 20027451
//DATE: 2019/03/20

namespace JadenDzubielChapterFive
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            decimal dec_invest, dec_annual, dec_interest;
            int int_year;

            //write list box heading
            list_display.Items.Add("Year\tAmount\tAnnual\t\tInterest Rate");
           
            if (!decimal.TryParse(txt_investment.Text, out dec_invest))
            {
                MessageBox.Show("A number was not entered - please enter your Investment Amount again");
                txt_investment.Clear();
                txt_investment.Focus();
            }

            if (!decimal.TryParse(txt_annual.Text, out dec_annual))
            {
                MessageBox.Show("A number was not entered - please enter your Annual Interest Rate again");
                txt_annual.Clear();
                txt_annual.Focus();
            }

            int_year = 1; //set first value

            while (int_year <= 10)
            {
                dec_interest = dec_invest * (dec_annual / 100) * int_year;
                list_display.Items.Add(int_year.ToString() + "\t" + dec_invest.ToString("c") + "\t" + dec_annual.ToString() + "%" + "\t\t" + dec_interest.ToString("c"));
                int_year += 1; //change the first the the next value
            }
        }

        private void list_display_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
