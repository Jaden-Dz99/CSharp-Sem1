﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Programmer: JADEN DZUBIEL
//Number: 20027451
//DATE: 2019/03/20
//Purpose:  To create multiplication list box , times table (from 1 to 12). 

namespace JadenDzubielChapterFive
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void txt_value_TextChanged(object sender, EventArgs e)
        {

        }
        private void btn_displayMultiplication_Click(object sender, EventArgs e)
        {
                int int_first, int_second, int_result;

                
                list_display.Items.Add("Value\t\tResult"); // \t\t mean two tabs

                
                if (!int.TryParse(txt_value.Text, out int_second))
                {
                    MessageBox.Show("A number was not entered - please enter your Amount Collected again");
                    txt_value.Clear();
                    txt_value.Focus();

                }

                int_first = 1; 

                while (int_first <= 12)
                {
                    int_result = int_first * int_second;

                    list_display.Items.Add(int_first.ToString() + "x" + int_second.ToString() + "\t\t" + int_result.ToString());

                    int_first += 1; //change int_first to the next value
                }           
        }
    }
}
