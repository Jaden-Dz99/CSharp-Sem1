﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Programmer: JADEN DZUBIEL
//Number: 20027451
//DATE: 2019/03/20
//Purpose: To create and place the numbers 0.5, 1.0, 1.5, ..., 4.5, 5.0 in a list box called list squares along with their matching squares. 

namespace JadenDzubielChapterFive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_displayMultiplication_Click(object sender, EventArgs e)
        {
            int int_first, int_second, int_result;

            
            list_display.Items.Add("Value\t\tResult"); // \t\t mean two tabs


            int_first = 1; 
            int_second = 3; 



            while (int_first <= 12)
            {
                int_result = int_first * int_second;

                list_display.Items.Add(int_first.ToString() + "x" + int_second.ToString() + "\t\t" + int_result.ToString());

                int_first += 1; 
            }
        }
    }
}
