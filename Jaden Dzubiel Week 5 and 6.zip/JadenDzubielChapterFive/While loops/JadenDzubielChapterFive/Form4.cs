﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Programmer: JADEN DZUBIEL
//Number: 20027451
//DATE: 2019/03/20

namespace JadenDzubielChapterFive
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            int intcount = 0;
            int intnumber = 0;

            //Validate the input
            if (!int.TryParse(txt_value.Text, out intnumber))
            {
                MessageBox.Show("A number was not entered - please enter your Number again");
                txt_value.Clear();
                txt_value.Focus();
            }

            while (intnumber >= 1)
            {
                intnumber = intnumber / 2;
                intcount++;
            }

            txt_answer.Text = intcount.ToString();
        }

        private void txt_value_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
