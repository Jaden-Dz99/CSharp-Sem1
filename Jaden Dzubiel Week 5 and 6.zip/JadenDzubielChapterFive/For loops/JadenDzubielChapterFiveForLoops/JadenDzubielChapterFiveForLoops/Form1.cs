﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielChapterFiveForLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_one_Click(object sender, EventArgs e)
        {
            int int_num;

            list_numbers.Items.Clear(); 
            list_numbers.Items.Add("Number");

            for (int_num = 1; int_num <= 15; int_num++)
            {
                list_numbers.Items.Add(int_num);
            }
        }

        private void btn_two_Click(object sender, EventArgs e)
        {
            int int_num;

            list_numbers.Items.Clear();
            list_numbers.Items.Add("Number");

            for (int_num = 1; int_num <= 15; int_num+=2)
            {
                list_numbers.Items.Add(int_num);
            }
        }

        private void btn_three_Click(object sender, EventArgs e)
        {
            int int_num;

            list_numbers.Items.Clear();
            list_numbers.Items.Add("Number");

            for (int_num = 25; int_num >= 1; int_num -=3)
            {
                list_numbers.Items.Add(int_num);
            }
        }
    }
}
