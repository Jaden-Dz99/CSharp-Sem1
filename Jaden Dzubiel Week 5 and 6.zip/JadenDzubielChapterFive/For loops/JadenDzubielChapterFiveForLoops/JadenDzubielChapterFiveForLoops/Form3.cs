﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielChapterFiveForLoops

//Programmer: JADEN DZUBIEL
//Number: 20027451
//DATE: 2019/03/20
//Purpose: To display counting numbers with their matching squares.

{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            float flt_number, flt_square;
      
            list_display.Items.Add("Number\t\tSquare"); 

            for (flt_number = 0.5F; flt_number <= 5.0; flt_number += 0.5F)
            {
                flt_square = (float)Math.Pow(flt_number, 2);
                list_display.Items.Add(flt_number.ToString() + "\t\t" + flt_square.ToString());
            }
        }
    }
}
