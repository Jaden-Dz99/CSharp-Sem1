﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Programmer: JADEN DZUBIEL
//Number: 20027451
//DATE: 2019/03/20
//Purpose: Display number with divided value

namespace JadenDzubielChapterFiveForLoops
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            int n;
            int count;
         
            if (!int.TryParse(txt_value.Text, out n))
            {
                MessageBox.Show("A number was not entered - please enter your Number again");
                txt_value.Clear();
                txt_value.Focus();
            }

            list_display.Items.Add("Number that can be divided\t"); 

            for (count = 1; count <= n; count++)
            {
                if (n % count == 0)
                    list_display.Items.Add(count);
            }
        }
    }
}
