﻿namespace JadenDzubielChapterFiveForLoops
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_one = new System.Windows.Forms.Button();
            this.btn_two = new System.Windows.Forms.Button();
            this.btn_three = new System.Windows.Forms.Button();
            this.list_numbers = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_one
            // 
            this.btn_one.Location = new System.Drawing.Point(76, 19);
            this.btn_one.Name = "btn_one";
            this.btn_one.Size = new System.Drawing.Size(99, 34);
            this.btn_one.TabIndex = 0;
            this.btn_one.Text = "Up by One";
            this.btn_one.UseVisualStyleBackColor = true;
            this.btn_one.Click += new System.EventHandler(this.btn_one_Click);
            // 
            // btn_two
            // 
            this.btn_two.Location = new System.Drawing.Point(76, 59);
            this.btn_two.Name = "btn_two";
            this.btn_two.Size = new System.Drawing.Size(99, 34);
            this.btn_two.TabIndex = 1;
            this.btn_two.Text = "Up by Two";
            this.btn_two.UseVisualStyleBackColor = true;
            this.btn_two.Click += new System.EventHandler(this.btn_two_Click);
            // 
            // btn_three
            // 
            this.btn_three.Location = new System.Drawing.Point(76, 99);
            this.btn_three.Name = "btn_three";
            this.btn_three.Size = new System.Drawing.Size(99, 34);
            this.btn_three.TabIndex = 2;
            this.btn_three.Text = "Down by Three";
            this.btn_three.UseVisualStyleBackColor = true;
            this.btn_three.Click += new System.EventHandler(this.btn_three_Click);
            // 
            // list_numbers
            // 
            this.list_numbers.FormattingEnabled = true;
            this.list_numbers.Location = new System.Drawing.Point(76, 144);
            this.list_numbers.Name = "list_numbers";
            this.list_numbers.Size = new System.Drawing.Size(98, 225);
            this.list_numbers.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(241, 450);
            this.Controls.Add(this.list_numbers);
            this.Controls.Add(this.btn_three);
            this.Controls.Add(this.btn_two);
            this.Controls.Add(this.btn_one);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_one;
        private System.Windows.Forms.Button btn_two;
        private System.Windows.Forms.Button btn_three;
        private System.Windows.Forms.ListBox list_numbers;
    }
}

