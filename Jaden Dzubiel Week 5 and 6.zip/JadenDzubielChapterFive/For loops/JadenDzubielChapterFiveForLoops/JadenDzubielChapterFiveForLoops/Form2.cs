﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielChapterFiveForLoops
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_one_Click(object sender, EventArgs e)
        {
            int int_number;
            float flt_square;
            
            list_display.Items.Add("Number\t\tSquare");

            for (int_number = 1; int_number <= 12; int_number += 1)
            {
                flt_square = (float)Math.Pow(int_number, 2);
                list_display.Items.Add(int_number.ToString() + "\t\t" + flt_square.ToString());
            }
        }

        private void btn_two_Click(object sender, EventArgs e)
        {
            int int_number;
            float flt_square;

            list_display.Items.Add("Number\t\tSquare");

            for (int_number = 1; int_number <= 12; int_number += 2)
            {
                flt_square = (float)Math.Pow(int_number, 2);
                list_display.Items.Add(int_number.ToString() + "\t\t" + flt_square.ToString());
            }
        }

        private void btn_three_Click(object sender, EventArgs e)
        {
            int int_number;
            float flt_square;

            list_display.Items.Add("Number\t\tSquare");

            for (int_number = 12; int_number >= 1; int_number -= 4)
            {
                flt_square = (float)Math.Pow(int_number, 2);
                list_display.Items.Add(int_number.ToString() + "\t\t" + flt_square.ToString());
            }
        }
    }
}
