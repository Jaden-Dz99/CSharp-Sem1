﻿namespace JadenDzubielChapterFiveForLoops
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_display = new System.Windows.Forms.Button();
            this.list_display = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_display
            // 
            this.btn_display.Location = new System.Drawing.Point(73, 33);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(109, 32);
            this.btn_display.TabIndex = 0;
            this.btn_display.Text = "Display Square";
            this.btn_display.UseVisualStyleBackColor = true;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // list_display
            // 
            this.list_display.FormattingEnabled = true;
            this.list_display.Location = new System.Drawing.Point(26, 81);
            this.list_display.Name = "list_display";
            this.list_display.Size = new System.Drawing.Size(216, 212);
            this.list_display.TabIndex = 1;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 350);
            this.Controls.Add(this.list_display);
            this.Controls.Add(this.btn_display);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.ListBox list_display;
    }
}