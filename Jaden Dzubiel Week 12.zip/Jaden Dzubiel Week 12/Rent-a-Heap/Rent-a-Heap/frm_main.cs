﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_a_Heap
{
    public partial class frm_main : Form
    {
        public frm_main()
        {
            InitializeComponent();
        }

        private void btn_small_Click(object sender, EventArgs e)
        {
            Form1 frm_small = new Form1();
            frm_small.ShowDialog();
        }

        private void btn_medium_Click(object sender, EventArgs e)
        {
            Form2 frm_medium = new Form2();
            frm_medium.ShowDialog();
        }

        private void btn_Large_Click(object sender, EventArgs e)
        {
            Form3 frm_large = new Form3();
            frm_large.ShowDialog();
        }
    }
}
