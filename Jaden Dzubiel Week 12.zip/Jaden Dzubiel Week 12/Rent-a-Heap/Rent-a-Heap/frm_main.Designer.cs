﻿namespace Rent_a_Heap
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_small = new System.Windows.Forms.Button();
            this.btn_medium = new System.Windows.Forms.Button();
            this.btn_Large = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_small
            // 
            this.btn_small.Location = new System.Drawing.Point(61, 48);
            this.btn_small.Name = "btn_small";
            this.btn_small.Size = new System.Drawing.Size(74, 28);
            this.btn_small.TabIndex = 0;
            this.btn_small.Text = "Small";
            this.btn_small.UseVisualStyleBackColor = true;
            this.btn_small.Click += new System.EventHandler(this.btn_small_Click);
            // 
            // btn_medium
            // 
            this.btn_medium.Location = new System.Drawing.Point(61, 97);
            this.btn_medium.Name = "btn_medium";
            this.btn_medium.Size = new System.Drawing.Size(74, 28);
            this.btn_medium.TabIndex = 1;
            this.btn_medium.Text = "Medium";
            this.btn_medium.UseVisualStyleBackColor = true;
            this.btn_medium.Click += new System.EventHandler(this.btn_medium_Click);
            // 
            // btn_Large
            // 
            this.btn_Large.Location = new System.Drawing.Point(61, 149);
            this.btn_Large.Name = "btn_Large";
            this.btn_Large.Size = new System.Drawing.Size(74, 28);
            this.btn_Large.TabIndex = 2;
            this.btn_Large.Text = "Large";
            this.btn_Large.UseVisualStyleBackColor = true;
            this.btn_Large.Click += new System.EventHandler(this.btn_Large_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select the car type:";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(205, 200);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Large);
            this.Controls.Add(this.btn_medium);
            this.Controls.Add(this.btn_small);
            this.Name = "frm_main";
            this.Text = "frm_main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_small;
        private System.Windows.Forms.Button btn_medium;
        private System.Windows.Forms.Button btn_Large;
        private System.Windows.Forms.Label label1;
    }
}