﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_a_Heap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txt_days_TextChanged(object sender, EventArgs e)
        {
            int day, hire;

            //String to Number
            if (!int.TryParse(txt_days.Text, out day))
            {
                MessageBox.Show("A number was not entered – please enter the number again");
                txt_days.Clear();
                txt_days.Focus();
                return;
            }
            
            hire = day * 20;

            txt_hire.Text = hire.ToString("c");
        }

        private void txt_hire_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
