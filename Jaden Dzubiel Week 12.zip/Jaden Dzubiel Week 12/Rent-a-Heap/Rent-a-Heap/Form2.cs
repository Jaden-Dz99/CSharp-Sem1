﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_a_Heap
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void txt_days_TextChanged(object sender, EventArgs e)
        {
            int day, hire;

            if (!int.TryParse(txt_days.Text, out day))
            {
                MessageBox.Show("A number was not entered – please enter number again");
                txt_days.Clear();
                txt_days.Focus();
                return;
            }

            hire = day * 30;

            txt_hire.Text = hire.ToString("c");
        }
    }
}
