﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransferName
{
    public partial class frm_display : Form
    {
        public static string[] str_names = new string[10];
        int count = 0;

        public frm_display(int i, string[]names)
        {
            InitializeComponent();
            count = i;
            str_names = names;
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            int s;
            lst_display_2.Items.Clear();

            lst_display_2.Items.Add("NAME");

            for (s = 0; s < count; s++)
            {
                lst_display_2.Items.Add(str_names[s].ToString());

            }
        }
    }
}
