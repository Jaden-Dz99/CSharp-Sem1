﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransferName
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string[] str_names = new string[10];
        int count = 0;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_accept_Click(object sender, EventArgs e)
        {
            string names;
            names = txt_name.Text;

            if (txt_name.Text == "")   
            {
                MessageBox.Show("The name can not be blank - enter the name");
                txt_name.Focus();
            }
            else if (count == 10)
            {
                MessageBox.Show("Array is full");
                txt_name.Focus();
            }
            else
            {              
                str_names[count] = txt_name.Text;
                count++;
                txt_name.Clear();
                txt_name.Focus();
            }
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            int s;

            lst_result.Items.Clear();

            lst_result.Items.Add("NAME");

            for (s = 0; s < count; s++)
            {
                lst_result.Items.Add(str_names[s].ToString());

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {           
            frm_display frm_show_data = new frm_display(count, str_names);
            frm_show_data.ShowDialog();
        }
    }
}
