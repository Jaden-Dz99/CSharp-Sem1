﻿namespace TransferName
{
    partial class frm_display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_display_2 = new System.Windows.Forms.ListBox();
            this.btn_display = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lst_display_2
            // 
            this.lst_display_2.FormattingEnabled = true;
            this.lst_display_2.Location = new System.Drawing.Point(20, 73);
            this.lst_display_2.Name = "lst_display_2";
            this.lst_display_2.Size = new System.Drawing.Size(338, 225);
            this.lst_display_2.TabIndex = 0;
            // 
            // btn_display
            // 
            this.btn_display.Location = new System.Drawing.Point(131, 15);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(109, 41);
            this.btn_display.TabIndex = 1;
            this.btn_display.Text = "Display";
            this.btn_display.UseVisualStyleBackColor = true;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // frm_display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 331);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.lst_display_2);
            this.Name = "frm_display";
            this.Text = "frm_display";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lst_display_2;
        private System.Windows.Forms.Button btn_display;
    }
}