﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jaden_Dzubiel_Week_13
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_height_Click(object sender, EventArgs e)
        {
            lstbox.Items.Clear();

            lstbox2.Items.Clear();

            double[] heights = new double[100];

            Random random_heights = new Random();

            double height;

            double index = 0;

            double average;

            int less_than_120 = 0, from_120_to_139 = 0, from_140_to_159 = 0, from_160_to_179 = 0, from_180_to_199 = 0, from_200_to_219 = 0, from_220_to_239 = 0, from_240_to_259 = 0, more_than_260 = 0;


            for (int s = 0; s < 100; s++)
            {
                height = random_heights.NextDouble() * (2.75 - 1.0) + 1.0;
                heights[s] = height;

                lstbox.Items.Add(heights[s].ToString("F"));

                index = index + heights[s];

                if (height < 1.20)
                {
                    less_than_120++;
                }
                if (height >= 1.20 && height < 1.40)
                {
                    from_120_to_139++;
                }
                if (height >= 1.40 && height < 1.60)
                {
                    from_140_to_159++;
                }
                if (height >= 1.60 && height < 1.80)
                {
                    from_160_to_179++;
                }
                if (height >= 1.80 && height < 2.00)
                {
                    from_180_to_199++;
                }
                if (height >= 2.00 && height < 2.20)
                {
                    from_200_to_219++;
                }
                if (height >= 2.20 && height < 2.40)
                {
                    from_220_to_239++;
                }
                if (height >= 2.40 && height < 2.60)
                {
                    from_240_to_259++;
                }
                if (height > 2.60)
                {
                    more_than_260++;
                }

                average = index / 100;

                textBox1.Text = average.ToString("F");

                lstbox2.Items.Add("Below 1.20: " + less_than_120);
                lstbox2.Items.Add("From 1.20 to 1.39: " + from_120_to_139);
                lstbox2.Items.Add("From 1.40 to 1.59: " + from_140_to_159);
                lstbox2.Items.Add("From 1.60 to 1.79: " + from_160_to_179);
                lstbox2.Items.Add("From 1.80 to 1.99: " + from_180_to_199);
                lstbox2.Items.Add("From 2.00 to 2.19: " + from_200_to_219);
                lstbox2.Items.Add("From 2.20 to 2.39: " + from_220_to_239);
                lstbox2.Items.Add("From 2.40 to 2.59: " + from_240_to_259);
                lstbox2.Items.Add("Above 2.60: " + more_than_260);
            }
    }
}
