﻿namespace Jaden_Dzubiel_Week_13
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_lotto = new System.Windows.Forms.Button();
            this.lstlotto = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_lotto
            // 
            this.btn_lotto.Location = new System.Drawing.Point(60, 33);
            this.btn_lotto.Name = "btn_lotto";
            this.btn_lotto.Size = new System.Drawing.Size(204, 26);
            this.btn_lotto.TabIndex = 0;
            this.btn_lotto.Text = "Generate Lotto Numbers";
            this.btn_lotto.UseVisualStyleBackColor = true;
            this.btn_lotto.Click += new System.EventHandler(this.btn_lotto_Click);
            // 
            // lstlotto
            // 
            this.lstlotto.FormattingEnabled = true;
            this.lstlotto.Location = new System.Drawing.Point(15, 74);
            this.lstlotto.Name = "lstlotto";
            this.lstlotto.Size = new System.Drawing.Size(296, 355);
            this.lstlotto.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 450);
            this.Controls.Add(this.lstlotto);
            this.Controls.Add(this.btn_lotto);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_lotto;
        private System.Windows.Forms.ListBox lstlotto;
    }
}

