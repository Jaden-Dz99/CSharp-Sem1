﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jaden_Dzubiel_Week_13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_lotto_Click(object sender, EventArgs e)
        {
            lstlotto.Items.Clear();

            Random lotto_generator = new Random(DateTime.Now.Millisecond);

            int[] array = new int[7];

            int index;

            int random_num;

            for (index = 1; index < 7; index++)
            {
                random_num = lotto_generator.Next(1, 46);


                if (!array.Contains(random_num))
                {
                    array[index] = random_num;
                }

                else
                {
                    index--;
                }

                array[index] = random_num;
                lstlotto.Items.Add(array[index]);

            }
        }
    }
}
