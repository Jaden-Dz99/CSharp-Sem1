﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jaden_Dzubiel_Week_13
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_numbers_Click(object sender, EventArgs e)
        {
            lstrandom.Items.Clear();

            Random num_generator = new Random(DateTime.Now.Millisecond);

            int[] array = new int[11];

            int index;

            int random_num;

            for (index = 1; index < 11; index++)
            {
                random_num = num_generator.Next(57, 94);
                array[index] = random_num;
                
                lstrandom.Items.Add(array[index] / 10);
            }
        }
    }
    }
}
