﻿namespace Jaden_Dzubiel_Week_13
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbox = new System.Windows.Forms.ListBox();
            this.lstbox2 = new System.Windows.Forms.ListBox();
            this.btn_height = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_height = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lstbox
            // 
            this.lstbox.FormattingEnabled = true;
            this.lstbox.Location = new System.Drawing.Point(12, 109);
            this.lstbox.Name = "lstbox";
            this.lstbox.Size = new System.Drawing.Size(140, 277);
            this.lstbox.TabIndex = 0;
            // 
            // lstbox2
            // 
            this.lstbox2.FormattingEnabled = true;
            this.lstbox2.Location = new System.Drawing.Point(197, 109);
            this.lstbox2.Name = "lstbox2";
            this.lstbox2.Size = new System.Drawing.Size(267, 277);
            this.lstbox2.TabIndex = 1;
            // 
            // btn_height
            // 
            this.btn_height.Location = new System.Drawing.Point(260, 66);
            this.btn_height.Name = "btn_height";
            this.btn_height.Size = new System.Drawing.Size(120, 23);
            this.btn_height.TabIndex = 2;
            this.btn_height.Text = "Generate Height";
            this.btn_height.UseVisualStyleBackColor = true;
            this.btn_height.Click += new System.EventHandler(this.btn_height_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(484, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Average Height";
            // 
            // txt_height
            // 
            this.txt_height.Location = new System.Drawing.Point(470, 134);
            this.txt_height.Name = "txt_height";
            this.txt_height.Size = new System.Drawing.Size(111, 20);
            this.txt_height.TabIndex = 4;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 398);
            this.Controls.Add(this.txt_height);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_height);
            this.Controls.Add(this.lstbox2);
            this.Controls.Add(this.lstbox);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstbox;
        private System.Windows.Forms.ListBox lstbox2;
        private System.Windows.Forms.Button btn_height;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_height;
    }
}