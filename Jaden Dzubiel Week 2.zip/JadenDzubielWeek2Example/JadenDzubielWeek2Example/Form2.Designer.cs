﻿namespace JadenDzubielWeek2Example
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_StopEntry = new System.Windows.Forms.Button();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_StopEntry
            // 
            this.btn_StopEntry.Location = new System.Drawing.Point(211, 79);
            this.btn_StopEntry.Name = "btn_StopEntry";
            this.btn_StopEntry.Size = new System.Drawing.Size(136, 38);
            this.btn_StopEntry.TabIndex = 0;
            this.btn_StopEntry.Text = "Stop Entry";
            this.btn_StopEntry.UseVisualStyleBackColor = true;
            this.btn_StopEntry.Click += new System.EventHandler(this.btn_StopEntry_Click);
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(79, 31);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(378, 20);
            this.txt_Name.TabIndex = 1;
            this.txt_Name.TextChanged += new System.EventHandler(this.txt_Name_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 197);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.btn_StopEntry);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_StopEntry;
        private System.Windows.Forms.TextBox txt_Name;
    }
}