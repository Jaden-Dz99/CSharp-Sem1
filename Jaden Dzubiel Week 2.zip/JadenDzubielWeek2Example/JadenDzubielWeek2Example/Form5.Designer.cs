﻿namespace JadenDzubielWeek2Example
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Box = new System.Windows.Forms.TextBox();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_Box
            // 
            this.txt_Box.Location = new System.Drawing.Point(205, 90);
            this.txt_Box.Name = "txt_Box";
            this.txt_Box.Size = new System.Drawing.Size(100, 20);
            this.txt_Box.TabIndex = 0;
            this.txt_Box.TextChanged += new System.EventHandler(this.txt_Box_TextChanged);
            this.txt_Box.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_Box_KeyUp);
            // 
            // lbl_1
            // 
            this.lbl_1.AutoSize = true;
            this.lbl_1.Location = new System.Drawing.Point(1, 5);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(80, 13);
            this.lbl_1.TabIndex = 1;
            this.lbl_1.Text = "Changed Again";
            this.lbl_1.Click += new System.EventHandler(this.lbl_1_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_1);
            this.Controls.Add(this.txt_Box);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Box;
        private System.Windows.Forms.Label lbl_1;
    }
}