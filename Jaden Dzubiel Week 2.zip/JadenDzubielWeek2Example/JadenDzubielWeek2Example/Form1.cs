﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek2Example
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Change_Click(object sender, EventArgs e)
        {
            txt_Name.Text = "Alan";
            txt_Name.Text = txt_GName.Text;
            txt_Name.BackColor = Color.Blue;
            txt_Name.Font = new Font("Arial", 12, FontStyle.Bold);
            txt_GName.Font = new Font("Times New Roman", 16);
            txt_GName.BackColor = Color.Yellow;
            txt_GName.ForeColor = Color.Blue;
            Form1.ActiveForm.BackColor = Color.Blue;
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            txt_Name.Visible = false;
            btn_Hide.Visible = false;
            btn_Show.Visible = true;
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            txt_Name.Visible = true;
            btn_Show.Visible = false;
            btn_Hide.Visible = true;
        }
    }
}
