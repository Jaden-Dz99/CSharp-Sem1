﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek2Example
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_FullName.Text = " ";
            txt_GivenName.Text = " ";
            txt_LastName.Text = " ";
            
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            txt_FullName.Text = txt_GivenName.Text + " " + txt_LastName.Text;
        }

        private void txt_FullName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_LastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_GivenName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
