﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek2Example
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void txt_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_StopEntry_Click(object sender, EventArgs e)
        {
            txt_Name.ReadOnly = true;
        }
    }
}
