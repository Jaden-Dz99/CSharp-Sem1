﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek2Example
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void lbl_1_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_Box_TextChanged(object sender, EventArgs e)
        {
            lbl_1.Text = lbl_1.Text + "Changed Again" + "\n";
        }

        private void txt_Box_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Space)
            {
                lbl_1.Text = " ";
            }
        }
    }
}
