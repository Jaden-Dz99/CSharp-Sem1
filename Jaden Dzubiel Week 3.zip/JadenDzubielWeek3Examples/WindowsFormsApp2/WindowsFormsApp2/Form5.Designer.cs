﻿namespace WindowsFormsApp2
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_calculate = new System.Windows.Forms.Button();
            this.lbl_month = new System.Windows.Forms.Label();
            this.txt_month = new System.Windows.Forms.TextBox();
            this.txt_calls = new System.Windows.Forms.TextBox();
            this.lbl_calls = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_TotalCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_calculate
            // 
            this.btn_calculate.Location = new System.Drawing.Point(40, 120);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(238, 52);
            this.btn_calculate.TabIndex = 0;
            this.btn_calculate.Text = "Calculate";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // lbl_month
            // 
            this.lbl_month.AutoSize = true;
            this.lbl_month.Location = new System.Drawing.Point(38, 60);
            this.lbl_month.Name = "lbl_month";
            this.lbl_month.Size = new System.Drawing.Size(151, 13);
            this.lbl_month.TabIndex = 1;
            this.lbl_month.Text = "Additional $33 month Charges:";
            this.lbl_month.Click += new System.EventHandler(this.lbl_month_Click);
            // 
            // txt_month
            // 
            this.txt_month.Location = new System.Drawing.Point(203, 57);
            this.txt_month.Name = "txt_month";
            this.txt_month.Size = new System.Drawing.Size(76, 20);
            this.txt_month.TabIndex = 2;
            this.txt_month.TextChanged += new System.EventHandler(this.txt_month_TextChanged);
            // 
            // txt_calls
            // 
            this.txt_calls.Location = new System.Drawing.Point(203, 25);
            this.txt_calls.Name = "txt_calls";
            this.txt_calls.Size = new System.Drawing.Size(75, 20);
            this.txt_calls.TabIndex = 3;
            this.txt_calls.TextChanged += new System.EventHandler(this.txt_calls_TextChanged);
            // 
            // lbl_calls
            // 
            this.lbl_calls.AutoSize = true;
            this.lbl_calls.Location = new System.Drawing.Point(38, 28);
            this.lbl_calls.Name = "lbl_calls";
            this.lbl_calls.Size = new System.Drawing.Size(124, 13);
            this.lbl_calls.TabIndex = 4;
            this.lbl_calls.Text = "15c Phone Call Charges:";
            this.lbl_calls.Click += new System.EventHandler(this.lbl_calls_Click);
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Location = new System.Drawing.Point(39, 91);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(55, 13);
            this.lbl_Total.TabIndex = 5;
            this.lbl_Total.Text = "Total Cost";
            // 
            // lbl_TotalCost
            // 
            this.lbl_TotalCost.AutoSize = true;
            this.lbl_TotalCost.Location = new System.Drawing.Point(232, 91);
            this.lbl_TotalCost.Name = "lbl_TotalCost";
            this.lbl_TotalCost.Size = new System.Drawing.Size(13, 13);
            this.lbl_TotalCost.TabIndex = 6;
            this.lbl_TotalCost.Text = "0";
            this.lbl_TotalCost.Click += new System.EventHandler(this.lbl_TotalCost_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 201);
            this.Controls.Add(this.lbl_TotalCost);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.lbl_calls);
            this.Controls.Add(this.txt_calls);
            this.Controls.Add(this.txt_month);
            this.Controls.Add(this.lbl_month);
            this.Controls.Add(this.btn_calculate);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.Label lbl_month;
        private System.Windows.Forms.TextBox txt_month;
        private System.Windows.Forms.TextBox txt_calls;
        private System.Windows.Forms.Label lbl_calls;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lbl_TotalCost;
    }
}