﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_convert_Click(object sender, EventArgs e)
        {
            int intdays, intweeks;
            intdays = int.Parse(txt_input.Text);
            intweeks = int.Parse(txt_input.Text);
            lbl_output.Text = intweeks / 7 + " Weeks and " + intdays % 7 + " Days ";
        }

        private void lbl_output_Click(object sender, EventArgs e)
        {

        }

        private void txt_input_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
