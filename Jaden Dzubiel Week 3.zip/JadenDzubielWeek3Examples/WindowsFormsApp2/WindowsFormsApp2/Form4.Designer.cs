﻿namespace WindowsFormsApp2
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_calculate = new System.Windows.Forms.Button();
            this.txt_hours = new System.Windows.Forms.TextBox();
            this.lbl_hours = new System.Windows.Forms.Label();
            this.lbl_callout = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_TotalCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_calculate
            // 
            this.btn_calculate.Location = new System.Drawing.Point(31, 195);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(228, 71);
            this.btn_calculate.TabIndex = 0;
            this.btn_calculate.Text = "Calculate Job Cost";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // txt_hours
            // 
            this.txt_hours.Location = new System.Drawing.Point(164, 25);
            this.txt_hours.Name = "txt_hours";
            this.txt_hours.Size = new System.Drawing.Size(100, 20);
            this.txt_hours.TabIndex = 1;
            this.txt_hours.TextChanged += new System.EventHandler(this.txt_hours_TextChanged);
            // 
            // lbl_hours
            // 
            this.lbl_hours.AutoSize = true;
            this.lbl_hours.Location = new System.Drawing.Point(33, 25);
            this.lbl_hours.Name = "lbl_hours";
            this.lbl_hours.Size = new System.Drawing.Size(125, 13);
            this.lbl_hours.TabIndex = 2;
            this.lbl_hours.Text = "Amount of hours worked:";
            this.lbl_hours.Click += new System.EventHandler(this.lbl_hours_Click);
            // 
            // lbl_callout
            // 
            this.lbl_callout.AutoSize = true;
            this.lbl_callout.Location = new System.Drawing.Point(33, 142);
            this.lbl_callout.Name = "lbl_callout";
            this.lbl_callout.Size = new System.Drawing.Size(142, 13);
            this.lbl_callout.TabIndex = 3;
            this.lbl_callout.Text = "Additional $60 for Callout fee";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Location = new System.Drawing.Point(33, 179);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(58, 13);
            this.lbl_Total.TabIndex = 4;
            this.lbl_Total.Text = "Total Cost:";
            this.lbl_Total.Click += new System.EventHandler(this.lbl_Total_Click);
            // 
            // lbl_TotalCost
            // 
            this.lbl_TotalCost.AutoSize = true;
            this.lbl_TotalCost.Location = new System.Drawing.Point(94, 179);
            this.lbl_TotalCost.Name = "lbl_TotalCost";
            this.lbl_TotalCost.Size = new System.Drawing.Size(13, 13);
            this.lbl_TotalCost.TabIndex = 5;
            this.lbl_TotalCost.Text = "0";
            this.lbl_TotalCost.Click += new System.EventHandler(this.lbl_TotalCost_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 280);
            this.Controls.Add(this.lbl_TotalCost);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.lbl_callout);
            this.Controls.Add(this.lbl_hours);
            this.Controls.Add(this.txt_hours);
            this.Controls.Add(this.btn_calculate);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.TextBox txt_hours;
        private System.Windows.Forms.Label lbl_hours;
        private System.Windows.Forms.Label lbl_callout;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lbl_TotalCost;
    }
}