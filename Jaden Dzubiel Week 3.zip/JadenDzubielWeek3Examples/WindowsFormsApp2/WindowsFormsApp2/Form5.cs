﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            double dblCalls, dblMonth, dblTotal;
            dblCalls = double.Parse(txt_calls.Text);
            dblMonth = double.Parse(txt_month.Text);
            dblCalls = (dblCalls * 0.15);
            dblMonth = (dblMonth * 33);
            dblTotal = dblCalls + dblMonth;
            lbl_TotalCost.Text = dblTotal.ToString("C");
        }

        private void txt_calls_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_calls_Click(object sender, EventArgs e)
        {

        }

        private void txt_month_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_month_Click(object sender, EventArgs e)
        {

        }

        private void lbl_TotalCost_Click(object sender, EventArgs e)
        {

        }
    }
}
