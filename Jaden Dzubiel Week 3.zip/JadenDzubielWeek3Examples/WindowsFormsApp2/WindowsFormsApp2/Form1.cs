﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Programmer    :   Jaden   
        //Date          :   February 2019
        //Purpose       :   To Square Inputs

            //Math.Pow(number, power)
        private void btn_calc_Click(object sender, EventArgs e)
        {
            double dblNumber, dblSquareValue;
            dblNumber = double.Parse(txt_input.Text);
            dblSquareValue = Math.Pow(dblNumber, 2);
            txt_output.Text = dblSquareValue.ToString("F2");
            lbl_output2.Text = "The square of " + txt_input.Text + " is " + dblSquareValue.ToString("F2");

        }

        private void txt_input_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txt_output_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_output2_Click(object sender, EventArgs e)
        {

        }
    }
}
