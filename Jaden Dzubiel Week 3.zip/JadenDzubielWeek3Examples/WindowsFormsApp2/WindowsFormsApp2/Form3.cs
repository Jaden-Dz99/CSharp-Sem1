﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_output_Click(object sender, EventArgs e)
        {
            double dblNumber;
            dblNumber = double.Parse(txt_input.Text);
            dblNumber = Math.PI * (4/3) * (Math.Pow(dblNumber, 3));
            lbl_output.Text = "The volume of a sphere of radius: " + txt_input.Text + " is " + dblNumber.ToString("F4");
        }

        private void txt_input_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_output_Click(object sender, EventArgs e)
        {

        }
    }
}
