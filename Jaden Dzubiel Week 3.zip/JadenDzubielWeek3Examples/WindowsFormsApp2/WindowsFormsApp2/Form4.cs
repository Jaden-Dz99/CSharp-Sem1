﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void lbl_Total_Click(object sender, EventArgs e)
        {

        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            double dblNumber;
            dblNumber = double.Parse(txt_hours.Text);
            dblNumber = (dblNumber * 90) + 60;
            lbl_TotalCost.Text = dblNumber.ToString("C");
        }

        private void txt_hours_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_hours_Click(object sender, EventArgs e)
        {

        }

        private void lbl_TotalCost_Click(object sender, EventArgs e)
        {

        }
    }
}
