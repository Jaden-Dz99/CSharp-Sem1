﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek9
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        struct store_type
        {
            public string name;
            public double price;
        };

        List<store_type> stores = new List<store_type>();
        private void btn_accept_Click(object sender, EventArgs e)
        {
            store_type product;
            double in_price;

            //validate entries
            if (txt_name.Text == "")
            {
                MessageBox.Show("The product name cannot be blank - Please enter the product name", "Data entry error");
                txt_name.Focus();
            }
            else if (!double.TryParse(textBox2.Text, out in_price))
            {
                MessageBox.Show("The entered price is not a number or you are not entered - please enter it again", "Data Entry Error");
                textBox2.SelectAll();
                textBox2.Focus();
            }
            else //for valid data put it in the list
            {
                //fill a single structure item
                product.name = txt_name.Text;
                product.price = in_price;

                //add the single structure variable to the list
                stores.Add(product);

                //prepare for the next entry of details for the next person
                txt_name.Clear();
                textBox2.Clear();


            }
        }

        private void btn_above_Click(object sender, EventArgs e)
        {
            double price_total, min_price = 10, count = 0;
            bool found = false;

            //add heading
            lst_list_of_product.Items.Add("Product Name" + "\t" + "Price");

            foreach (store_type product in stores)
            {
                if (product.price < min_price)
                {

                    MessageBox.Show("There were no or has some product with price lower than 10$");
                    found = true;
                }
                else
                {

                    // send them to the list box
                    lst_list_of_product.Items.Add(product.name + "\t\t" + product.price.ToString("c"));
                    found = false;
                }

            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            lst_list_of_product.Items.Clear();
        }
    }
}
