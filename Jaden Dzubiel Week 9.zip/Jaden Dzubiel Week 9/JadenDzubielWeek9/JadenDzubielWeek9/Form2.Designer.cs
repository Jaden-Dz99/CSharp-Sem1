﻿namespace JadenDzubielWeek9
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btn_accept = new System.Windows.Forms.Button();
            this.lst_list_of_product = new System.Windows.Forms.ListBox();
            this.btn_above = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Price";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(130, 18);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(130, 55);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btn_accept
            // 
            this.btn_accept.Location = new System.Drawing.Point(130, 90);
            this.btn_accept.Name = "btn_accept";
            this.btn_accept.Size = new System.Drawing.Size(100, 23);
            this.btn_accept.TabIndex = 4;
            this.btn_accept.Text = "Accept Product";
            this.btn_accept.UseVisualStyleBackColor = true;
            this.btn_accept.Click += new System.EventHandler(this.btn_accept_Click);
            // 
            // lst_list_of_product
            // 
            this.lst_list_of_product.FormattingEnabled = true;
            this.lst_list_of_product.Location = new System.Drawing.Point(131, 133);
            this.lst_list_of_product.Name = "lst_list_of_product";
            this.lst_list_of_product.Size = new System.Drawing.Size(227, 212);
            this.lst_list_of_product.TabIndex = 5;
            // 
            // btn_above
            // 
            this.btn_above.Location = new System.Drawing.Point(28, 175);
            this.btn_above.Name = "btn_above";
            this.btn_above.Size = new System.Drawing.Size(68, 35);
            this.btn_above.TabIndex = 6;
            this.btn_above.Text = "Product Above $10";
            this.btn_above.UseVisualStyleBackColor = true;
            this.btn_above.Click += new System.EventHandler(this.btn_above_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(28, 227);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(68, 35);
            this.btn_clear.TabIndex = 7;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 369);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_above);
            this.Controls.Add(this.lst_list_of_product);
            this.Controls.Add(this.btn_accept);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btn_accept;
        private System.Windows.Forms.ListBox lst_list_of_product;
        private System.Windows.Forms.Button btn_above;
        private System.Windows.Forms.Button btn_clear;
    }
}