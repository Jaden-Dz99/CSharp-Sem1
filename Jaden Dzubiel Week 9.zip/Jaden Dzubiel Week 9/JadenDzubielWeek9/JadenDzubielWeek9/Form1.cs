﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        struct person_details_type
        {
            public string name;
            public int age;

        };

        List<person_details_type> people = new List<person_details_type>();

        private void btn_accept_Click(object sender, EventArgs e)
        {
            person_details_type person;
            int in_age;

            //validate entries
            if (txt_name.Text == "")
            {
                MessageBox.Show("The name cannot be blank - Please enter the name", "Data entry error");

            }
            else if (!int.TryParse(txt_age.Text, out in_age))
            {
                MessageBox.Show("The entered age is not a number - Please enter it agian", "Data entry error");
            }
            else //for valid data put it in the list
            {
                //fill a single structure item
                person.name = txt_name.Text;
                person.age = in_age;

                //add the single structure variable to the list
                people.Add(person);

                //prepare for the next entry of details for the next person
                txt_name.Clear();
                txt_age.Clear();


            }
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            int age_total = 0, count = 0;
            float age_average;

            foreach (person_details_type person in people)
            {
                age_total += person.age;
                count++;
            }

            //calculate the avarages
            age_average = (float)age_total / (float)(count);
            count = count++;

            //send them to text box
            txt_average.Text = age_average.ToString("F2");
            txt_people.Text = count.ToString();
        }
    }
}
