﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace if_example_1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_Calculate_Click(object sender, EventArgs e)
        {
            double dblQuantity, dblInitial, dblTotal, dblDiscounts;

            if (!double.TryParse(txt_kL.Text, out dblQuantity))
            {
                MessageBox.Show("A number was not entered – please enter amount again");
                txt_kL.Clear();
                txt_kL.Focus();
                return;
            }

            dblQuantity = double.Parse(txt_kL.Text);
            dblDiscounts = (dblQuantity - 100) * 0.55;
            dblInitial = dblQuantity;
           

            if (dblQuantity < 100)
            {
                dblQuantity = dblQuantity * 0.35;
            }
            else
            {
                dblQuantity = 100 * 0.35 + dblDiscounts;
            }
            dblTotal = dblQuantity;
            lbl_Cost.Text = dblTotal.ToString("C");
        }

        private void txt_kL_TextChanged(object sender, EventArgs e)
        {
                
        }

        private void lbl_Cost_Click(object sender, EventArgs e)
        {

        }
    }
}
