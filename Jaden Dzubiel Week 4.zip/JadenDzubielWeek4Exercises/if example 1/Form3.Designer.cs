﻿namespace if_example_1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Cost = new System.Windows.Forms.TextBox();
            this.txt_Sell = new System.Windows.Forms.TextBox();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.btn_Calculate = new System.Windows.Forms.Button();
            this.lbl_Cost = new System.Windows.Forms.Label();
            this.lbl_Sell = new System.Windows.Forms.Label();
            this.lbl_If = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_Cost
            // 
            this.txt_Cost.Location = new System.Drawing.Point(240, 45);
            this.txt_Cost.Name = "txt_Cost";
            this.txt_Cost.Size = new System.Drawing.Size(100, 20);
            this.txt_Cost.TabIndex = 0;
            this.txt_Cost.TextChanged += new System.EventHandler(this.txt_Cost_TextChanged);
            // 
            // txt_Sell
            // 
            this.txt_Sell.Location = new System.Drawing.Point(240, 86);
            this.txt_Sell.Name = "txt_Sell";
            this.txt_Sell.Size = new System.Drawing.Size(100, 20);
            this.txt_Sell.TabIndex = 1;
            this.txt_Sell.TextChanged += new System.EventHandler(this.txt_Sell_TextChanged);
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Location = new System.Drawing.Point(321, 118);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(19, 13);
            this.lbl_Total.TabIndex = 2;
            this.lbl_Total.Text = "$0";
            this.lbl_Total.Click += new System.EventHandler(this.lbl_Total_Click);
            // 
            // btn_Calculate
            // 
            this.btn_Calculate.Location = new System.Drawing.Point(239, 168);
            this.btn_Calculate.Name = "btn_Calculate";
            this.btn_Calculate.Size = new System.Drawing.Size(100, 30);
            this.btn_Calculate.TabIndex = 3;
            this.btn_Calculate.Text = "Calculate";
            this.btn_Calculate.UseVisualStyleBackColor = true;
            this.btn_Calculate.Click += new System.EventHandler(this.btn_Calculate_Click);
            // 
            // lbl_Cost
            // 
            this.lbl_Cost.AutoSize = true;
            this.lbl_Cost.Location = new System.Drawing.Point(182, 48);
            this.lbl_Cost.Name = "lbl_Cost";
            this.lbl_Cost.Size = new System.Drawing.Size(31, 13);
            this.lbl_Cost.TabIndex = 4;
            this.lbl_Cost.Text = "Cost:";
            // 
            // lbl_Sell
            // 
            this.lbl_Sell.AutoSize = true;
            this.lbl_Sell.Location = new System.Drawing.Point(182, 89);
            this.lbl_Sell.Name = "lbl_Sell";
            this.lbl_Sell.Size = new System.Drawing.Size(47, 13);
            this.lbl_Sell.TabIndex = 5;
            this.lbl_Sell.Text = "Sells for:";
            // 
            // lbl_If
            // 
            this.lbl_If.AutoSize = true;
            this.lbl_If.Location = new System.Drawing.Point(362, 118);
            this.lbl_If.Name = "lbl_If";
            this.lbl_If.Size = new System.Drawing.Size(0, 13);
            this.lbl_If.TabIndex = 6;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 241);
            this.Controls.Add(this.lbl_If);
            this.Controls.Add(this.lbl_Sell);
            this.Controls.Add(this.lbl_Cost);
            this.Controls.Add(this.btn_Calculate);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.txt_Sell);
            this.Controls.Add(this.txt_Cost);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Cost;
        private System.Windows.Forms.TextBox txt_Sell;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Button btn_Calculate;
        private System.Windows.Forms.Label lbl_Cost;
        private System.Windows.Forms.Label lbl_Sell;
        private System.Windows.Forms.Label lbl_If;
    }
}