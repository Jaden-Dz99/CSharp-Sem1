﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace if_example_1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_Calculate_Click(object sender, EventArgs e)
        {
            double dblCost, dblSell, dblTotal;

            if (!double.TryParse(txt_Cost.Text, out dblCost))
            {
                MessageBox.Show("A number was not entered – please enter cost amount again");
                txt_Cost.Clear();
                txt_Cost.Focus();
                return;
            }

            if (!double.TryParse(txt_Sell.Text, out dblCost))
            {
                MessageBox.Show("A number was not entered – please enter sell amount again");
                txt_Sell.Clear();
                txt_Sell.Focus();
                return;
            }


            dblCost = double.Parse(txt_Cost.Text);
            dblSell = double.Parse(txt_Sell.Text);
            dblTotal = dblSell - dblCost;
            lbl_Total.Text = dblTotal.ToString("C");

            if (dblTotal > 0)
            {
                lbl_If.Text = "Profit";
            }
            else
            {
                lbl_If.Text = "Loss";
            }
        }

        private void txt_Cost_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Sell_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_Total_Click(object sender, EventArgs e)
        {

        }
    }
}
