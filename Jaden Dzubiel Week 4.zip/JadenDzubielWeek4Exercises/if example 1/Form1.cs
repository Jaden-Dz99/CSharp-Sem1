﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace if_example_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            double dblQuantity, dblTotal, dblDiscount;

            if (!double.TryParse (txt_quantity.Text, out dblQuantity))
            {
                MessageBox.Show("A number was not entered – please enter quantity again");
                txt_quantity.Clear();
                txt_quantity.Focus();
                return;
            }

            dblQuantity = double.Parse(txt_quantity.Text);
            dblDiscount = dblQuantity * 20 * 0.9;

                if (dblQuantity > 10)
            {
                dblQuantity = dblDiscount;
            }
                else
            {
                dblQuantity = dblQuantity * 20;
            }

            dblTotal = dblQuantity;
            lbl_Price.Text = dblTotal.ToString("C");

//              if (dblQuantity > DISCOUNT_START_LEVEL)
//            {
//              dec_discount = dec_purchase_amount * (decimal)DISCOUNT_RATE;
//            }
//              else
//            {
//               dec_discount = 0;
//            }

//            dec_amount_to_pay = dec_purchase_amount - dec_discount;
//
          
            

            
            //double dblCalls, dblMonth, dblTotal;
            //dblCalls = double.Parse(txt_calls.Text);
            //dblMonth = double.Parse(txt_month.Text);
            //dblCalls = (dblCalls * 0.15);
            //dblMonth = (dblMonth * 33);
            //dblTotal = dblCalls + dblMonth;
            //lbl_TotalCost.Text = dblTotal.ToString("C");
        }

        private void txt_quantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_Price_Click(object sender, EventArgs e)
        {

        }
    }
}
