﻿namespace if_example_1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Calculate = new System.Windows.Forms.Button();
            this.txt_kL = new System.Windows.Forms.TextBox();
            this.lbl_kL = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_Cost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Calculate
            // 
            this.btn_Calculate.Location = new System.Drawing.Point(126, 167);
            this.btn_Calculate.Name = "btn_Calculate";
            this.btn_Calculate.Size = new System.Drawing.Size(180, 49);
            this.btn_Calculate.TabIndex = 0;
            this.btn_Calculate.Text = "Calculate";
            this.btn_Calculate.UseVisualStyleBackColor = true;
            this.btn_Calculate.Click += new System.EventHandler(this.btn_Calculate_Click);
            // 
            // txt_kL
            // 
            this.txt_kL.Location = new System.Drawing.Point(126, 86);
            this.txt_kL.Name = "txt_kL";
            this.txt_kL.Size = new System.Drawing.Size(100, 20);
            this.txt_kL.TabIndex = 1;
            this.txt_kL.TextChanged += new System.EventHandler(this.txt_kL_TextChanged);
            // 
            // lbl_kL
            // 
            this.lbl_kL.AutoSize = true;
            this.lbl_kL.Location = new System.Drawing.Point(123, 53);
            this.lbl_kL.Name = "lbl_kL";
            this.lbl_kL.Size = new System.Drawing.Size(269, 13);
            this.lbl_kL.TabIndex = 2;
            this.lbl_kL.Text = "Amount of KiloLitres Used (Start and End of Year Total):";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Location = new System.Drawing.Point(123, 129);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(58, 13);
            this.lbl_Total.TabIndex = 3;
            this.lbl_Total.Text = "Total Cost:";
            // 
            // lbl_Cost
            // 
            this.lbl_Cost.AutoSize = true;
            this.lbl_Cost.Location = new System.Drawing.Point(198, 129);
            this.lbl_Cost.Name = "lbl_Cost";
            this.lbl_Cost.Size = new System.Drawing.Size(19, 13);
            this.lbl_Cost.TabIndex = 4;
            this.lbl_Cost.Text = "$0";
            this.lbl_Cost.Click += new System.EventHandler(this.lbl_Cost_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 270);
            this.Controls.Add(this.lbl_Cost);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.lbl_kL);
            this.Controls.Add(this.txt_kL);
            this.Controls.Add(this.btn_Calculate);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Calculate;
        private System.Windows.Forms.TextBox txt_kL;
        private System.Windows.Forms.Label lbl_kL;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lbl_Cost;
    }
}