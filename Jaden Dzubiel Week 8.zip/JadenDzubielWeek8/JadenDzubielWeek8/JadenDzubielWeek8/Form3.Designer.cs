﻿namespace JadenDzubielWeek8
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.btn_displayListNames = new System.Windows.Forms.Button();
            this.btn_sort = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_addName = new System.Windows.Forms.Button();
            this.list_names = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter your name:";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(120, 22);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 1;
            // 
            // btn_displayListNames
            // 
            this.btn_displayListNames.Location = new System.Drawing.Point(29, 49);
            this.btn_displayListNames.Name = "btn_displayListNames";
            this.btn_displayListNames.Size = new System.Drawing.Size(191, 22);
            this.btn_displayListNames.TabIndex = 2;
            this.btn_displayListNames.Text = "Display number of list Names";
            this.btn_displayListNames.UseVisualStyleBackColor = true;
            this.btn_displayListNames.Click += new System.EventHandler(this.btn_displayListNames_Click);
            // 
            // btn_sort
            // 
            this.btn_sort.Location = new System.Drawing.Point(30, 161);
            this.btn_sort.Name = "btn_sort";
            this.btn_sort.Size = new System.Drawing.Size(191, 22);
            this.btn_sort.TabIndex = 4;
            this.btn_sort.Text = "Sort the list";
            this.btn_sort.UseVisualStyleBackColor = true;
            this.btn_sort.Click += new System.EventHandler(this.btn_sort_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(29, 133);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(191, 22);
            this.btn_remove.TabIndex = 5;
            this.btn_remove.Text = "Remove the name selected";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(29, 105);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(191, 22);
            this.btn_delete.TabIndex = 6;
            this.btn_delete.Text = "Delete the entered name";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_addName
            // 
            this.btn_addName.Location = new System.Drawing.Point(29, 77);
            this.btn_addName.Name = "btn_addName";
            this.btn_addName.Size = new System.Drawing.Size(191, 22);
            this.btn_addName.TabIndex = 7;
            this.btn_addName.Text = "Add the name";
            this.btn_addName.UseVisualStyleBackColor = true;
            this.btn_addName.Click += new System.EventHandler(this.btn_addName_Click);
            // 
            // list_names
            // 
            this.list_names.FormattingEnabled = true;
            this.list_names.Location = new System.Drawing.Point(236, 51);
            this.list_names.Name = "list_names";
            this.list_names.Size = new System.Drawing.Size(214, 134);
            this.list_names.TabIndex = 8;
            this.list_names.SelectedIndexChanged += new System.EventHandler(this.list_names_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(233, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Names";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 210);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.list_names);
            this.Controls.Add(this.btn_addName);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.btn_sort);
            this.Controls.Add(this.btn_displayListNames);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_displayListNames;
        private System.Windows.Forms.Button btn_sort;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_addName;
        private System.Windows.Forms.ListBox list_names;
        private System.Windows.Forms.Label label2;
    }
}