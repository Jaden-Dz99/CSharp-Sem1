﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek8
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        List<string> pdct_name = new List<string>();
        List<double> pdct_price = new List<double>();

        private void btn_accept_Click(object sender, EventArgs e)
        {
            double price_in;

            if (String.IsNullOrEmpty(txt_name.Text))
            {
                MessageBox.Show("The product name is blank - please enter it", "Entry Error");
                txt_name.Focus();
            }
            else if (!double.TryParse(txt_price.Text, out price_in))
            {
                MessageBox.Show("The product price is not a number or blank - please enter it again", "Entry Error");
                txt_price.SelectAll();
                txt_price.Focus();
            }
            else
            {
                pdct_name.Add(txt_name.Text);
                pdct_price.Add(price_in);             
                txt_name.Clear();
                txt_price.Clear();
                txt_name.Focus();
            }
        }

        private void btn_aboveTen_Click(object sender, EventArgs e)
        {
            double required_price = 10;
            int s;
            bool found = false;

            list_product.Items.Add("Product Name" + "\t" + "Price");
            for (s = 0; s < pdct_price.Count; s++)
            {
                if (pdct_price[s] >= required_price)
                {
                    list_product.Items.Add(pdct_name[s] + "\t\t" + pdct_price[s].ToString("c"));
                    found = true;
                }
            }
            if (!found)
            {
                MessageBox.Show("There were no product with a price over 10$");
            }
        }

        private void list_product_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
