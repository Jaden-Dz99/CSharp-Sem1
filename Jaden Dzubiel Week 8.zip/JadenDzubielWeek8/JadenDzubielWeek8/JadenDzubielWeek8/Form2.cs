﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void list_method_SelectedIndexChanged(object sender, EventArgs e)
        {
            double[] dbl_prices = { 250, 900, 400 };
            int intproduct_index, int_numberoftraveller;
            double dbl_method_price, dbl_fare_price;

            if (list_method.SelectedIndex < 0) 
            {
                MessageBox.Show("Please select your journey");
            }
            else if (!int.TryParse(txt_number.Text, out int_numberoftraveller)) 
            {
                MessageBox.Show("The number required has not been entered or is not a number", "Invalid Entry");
                txt_number.SelectAll();
                txt_number.Focus();
            }
            else 
            {             
                intproduct_index = list_method.SelectedIndex;              
                dbl_method_price = dbl_prices[intproduct_index];               
                dbl_fare_price = dbl_method_price * int_numberoftraveller;
                txt_cost.Text = dbl_fare_price.ToString("c");
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_cost.Clear();
            txt_number.Clear();
            list_method.SelectedIndex = -1;
        }
    }
}
