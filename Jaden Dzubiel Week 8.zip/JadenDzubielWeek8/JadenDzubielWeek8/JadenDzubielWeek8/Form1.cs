﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_cost.Clear();
            txt_number.Clear();
            list_method.SelectedIndex = -1;
        }

        private void btn_cost_Click(object sender, EventArgs e)
        {
            //Declare array to hold prices matching the items
            double[] dbl_prices = { 250, 900, 400 };
            int intproduct_index, int_numberoftraveller;
            double dbl_method_price, dbl_fare_price;

            if (list_method.SelectedIndex < 0) //Item is checked to be selected
            {
                MessageBox.Show("Please select your journey");
            }
            else if (!int.TryParse(txt_number.Text, out int_numberoftraveller)) //Number to purchase is entered 
            {
                MessageBox.Show("The number required has not been entered or is not a number", "Invalid Entry");
                txt_number.SelectAll();
                txt_number.Focus();
            }
            else //calculate the charge
            {            
                intproduct_index = list_method.SelectedIndex;
                dbl_method_price = dbl_prices[intproduct_index];
                dbl_fare_price = dbl_method_price * int_numberoftraveller;
                txt_cost.Text = dbl_fare_price.ToString("C");
            }
        }

        private void list_method_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
