﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielWeek8
{
    public partial class Form3 : Form
    {
        List<string> str_name = new List<string>();

        public Form3()
        {
            InitializeComponent();
        }

        private void btn_displayListNames_Click(object sender, EventArgs e)
        {
            int s;           
            list_names.Items.Clear();
            list_names.Items.Add("Current Entered Name");

            for (s = 0; s < str_name.Count; s++)
            {

                list_names.Items.Add(str_name[s]);

            }
        }

        private void btn_addName_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_name.Text))
            {
                MessageBox.Show("The enter name box is blank - please enter it", "Entry Error");
                txt_name.Focus();
            }
            else
            {
                str_name.Add(txt_name.Text);
                txt_name.Clear();
                txt_name.Focus();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            list_names.Items.Clear();
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (list_names.SelectedIndex > -1)
                list_names.Items.RemoveAt(list_names.SelectedIndex);
        }

        private void btn_sort_Click(object sender, EventArgs e)
        {
            list_names.Sorted = true;
        }

        private void list_names_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
