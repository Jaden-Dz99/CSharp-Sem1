﻿namespace JadenDzubielWeek8
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.btn_accept = new System.Windows.Forms.Button();
            this.list_product = new System.Windows.Forms.ListBox();
            this.btn_aboveTen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Price:";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(123, 16);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(152, 20);
            this.txt_name.TabIndex = 2;
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(122, 47);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(153, 20);
            this.txt_price.TabIndex = 3;
            // 
            // btn_accept
            // 
            this.btn_accept.Location = new System.Drawing.Point(122, 78);
            this.btn_accept.Name = "btn_accept";
            this.btn_accept.Size = new System.Drawing.Size(153, 21);
            this.btn_accept.TabIndex = 4;
            this.btn_accept.Text = "Accept Product";
            this.btn_accept.UseVisualStyleBackColor = true;
            this.btn_accept.Click += new System.EventHandler(this.btn_accept_Click);
            // 
            // list_product
            // 
            this.list_product.FormattingEnabled = true;
            this.list_product.Location = new System.Drawing.Point(120, 112);
            this.list_product.Name = "list_product";
            this.list_product.Size = new System.Drawing.Size(155, 134);
            this.list_product.TabIndex = 5;
            this.list_product.SelectedIndexChanged += new System.EventHandler(this.list_product_SelectedIndexChanged);
            // 
            // btn_aboveTen
            // 
            this.btn_aboveTen.Location = new System.Drawing.Point(45, 112);
            this.btn_aboveTen.Name = "btn_aboveTen";
            this.btn_aboveTen.Size = new System.Drawing.Size(69, 48);
            this.btn_aboveTen.TabIndex = 6;
            this.btn_aboveTen.Text = "Product above $10";
            this.btn_aboveTen.UseVisualStyleBackColor = true;
            this.btn_aboveTen.Click += new System.EventHandler(this.btn_aboveTen_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 258);
            this.Controls.Add(this.btn_aboveTen);
            this.Controls.Add(this.list_product);
            this.Controls.Add(this.btn_accept);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Button btn_accept;
        private System.Windows.Forms.ListBox list_product;
        private System.Windows.Forms.Button btn_aboveTen;
    }
}