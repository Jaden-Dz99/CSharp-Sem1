﻿namespace JadenDzubielChapter7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_states = new System.Windows.Forms.Label();
            this.btn_displayState = new System.Windows.Forms.Button();
            this.btn_reverse = new System.Windows.Forms.Button();
            this.list_display = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lbl_states
            // 
            this.lbl_states.AutoSize = true;
            this.lbl_states.Location = new System.Drawing.Point(14, 42);
            this.lbl_states.Name = "lbl_states";
            this.lbl_states.Size = new System.Drawing.Size(98, 13);
            this.lbl_states.TabIndex = 0;
            this.lbl_states.Text = "States of Australia: ";
            // 
            // btn_displayState
            // 
            this.btn_displayState.Location = new System.Drawing.Point(118, 36);
            this.btn_displayState.Name = "btn_displayState";
            this.btn_displayState.Size = new System.Drawing.Size(126, 26);
            this.btn_displayState.TabIndex = 1;
            this.btn_displayState.Text = "Display";
            this.btn_displayState.UseVisualStyleBackColor = true;
            this.btn_displayState.Click += new System.EventHandler(this.btn_displayState_Click);
            // 
            // btn_reverse
            // 
            this.btn_reverse.Location = new System.Drawing.Point(118, 68);
            this.btn_reverse.Name = "btn_reverse";
            this.btn_reverse.Size = new System.Drawing.Size(126, 24);
            this.btn_reverse.TabIndex = 3;
            this.btn_reverse.Text = "Display Reverse";
            this.btn_reverse.UseVisualStyleBackColor = true;
            this.btn_reverse.Click += new System.EventHandler(this.btn_reverse_Click);
            // 
            // list_display
            // 
            this.list_display.FormattingEnabled = true;
            this.list_display.Location = new System.Drawing.Point(120, 109);
            this.list_display.Name = "list_display";
            this.list_display.Size = new System.Drawing.Size(123, 186);
            this.list_display.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 341);
            this.Controls.Add(this.list_display);
            this.Controls.Add(this.btn_reverse);
            this.Controls.Add(this.btn_displayState);
            this.Controls.Add(this.lbl_states);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_states;
        private System.Windows.Forms.Button btn_displayState;
        private System.Windows.Forms.Button btn_reverse;
        private System.Windows.Forms.ListBox list_display;
    }
}

