﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielChapter7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] str_states = { "West Australia", "South Australia", "New South Wales", "Queensland", "Victoria", "Tasmania" };
        private void btn_displayState_Click(object sender, EventArgs e)
        {
            int s;
            list_display.Items.Clear();
            for (s = 0; s < 6; s++)
            {
                list_display.Items.Add(str_states[s]);
            }
        }

        private void btn_reverse_Click(object sender, EventArgs e)
        {
            int s;
            list_display.Items.Clear();

            Array.Reverse(str_states);
            for (s = 0; s < 6; s++)
            {
                list_display.Items.Add(str_states[s]);          
            }
        }
    }
}
