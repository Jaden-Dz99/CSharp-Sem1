﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielChapter7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        string[] str_dogs = { "Corgi", "Boxer", "Husky", "Beagle", "Collie" };
        int[] int_dogs = { 1, 2, 3, 4, 5 };
        private void btn_display_Click(object sender, EventArgs e)
        {
            bool bool_dog_found = false;
            list_display.Visible = true;
            int s;
            list_display.Items.Clear();
            for (s = 0; s < 5; s++)
            {
                list_display.Items.Add(str_dogs[s] + "  \t" + int_dogs[s]);
            }

            if (!bool_dog_found)
            {
                list_display.Text = "Dog breed not found";
            }
        }
    }
}
