﻿namespace JadenDzubielChapter7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.list_display = new System.Windows.Forms.ListBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.btn_accept = new System.Windows.Forms.Button();
            this.btn_show = new System.Windows.Forms.Button();
            this.lbl_enteredNames = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // list_display
            // 
            this.list_display.FormattingEnabled = true;
            this.list_display.Location = new System.Drawing.Point(96, 112);
            this.list_display.Name = "list_display";
            this.list_display.Size = new System.Drawing.Size(142, 121);
            this.list_display.TabIndex = 0;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(4, 29);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(76, 13);
            this.lbl_name.TabIndex = 1;
            this.lbl_name.Text = "Enter a name: ";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(95, 26);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(142, 20);
            this.txt_name.TabIndex = 2;
            // 
            // btn_accept
            // 
            this.btn_accept.Location = new System.Drawing.Point(95, 52);
            this.btn_accept.Name = "btn_accept";
            this.btn_accept.Size = new System.Drawing.Size(142, 24);
            this.btn_accept.TabIndex = 3;
            this.btn_accept.Text = "Accept Entry";
            this.btn_accept.UseVisualStyleBackColor = true;
            this.btn_accept.Click += new System.EventHandler(this.btn_accept_Click);
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(96, 82);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(141, 24);
            this.btn_show.TabIndex = 4;
            this.btn_show.Text = "Show Names";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // lbl_enteredNames
            // 
            this.lbl_enteredNames.AutoSize = true;
            this.lbl_enteredNames.Location = new System.Drawing.Point(4, 112);
            this.lbl_enteredNames.Name = "lbl_enteredNames";
            this.lbl_enteredNames.Size = new System.Drawing.Size(86, 13);
            this.lbl_enteredNames.TabIndex = 5;
            this.lbl_enteredNames.Text = "Entered Names: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(253, 245);
            this.Controls.Add(this.lbl_enteredNames);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.btn_accept);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.list_display);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox list_display;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_accept;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.Label lbl_enteredNames;
    }
}

