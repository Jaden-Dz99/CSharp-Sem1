﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JadenDzubielChapter7
{
    public partial class Form1 : Form
    {
        string[] str_names = new string[10];
        int int_name_count = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_accept_Click(object sender, EventArgs e)
        {
            if (int_name_count >= 10)
            {
                MessageBox.Show("Array is full - Entry cannot be accepted");
            }
            else if (txt_name.Text == "")
            {
                MessageBox.Show("Entry cannot be blank - Please try again");
                txt_name.Focus();
            }
            else
            {
                str_names[int_name_count] = txt_name.Text;
                int_name_count++;

                txt_name.Clear();
                txt_name.Focus();
            }
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            int s;

            list_display.Items.Clear();

            for (s = int_name_count - 1; s >= 0; s--)
            {
                list_display.Items.Add(str_names[s]);
            }
        }
    }
}
